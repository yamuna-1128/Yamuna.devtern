const express = require("express");
const bcrypt = require("bcrypt");
const bodyParser = require("body-parser");
const path = require("path");
const app = express();
const PORT = 3000;

const users = [
  {
    username: "user1",
    password: "$2b$10$XKNt3qj9uQgpj/PL7np3v.fX6sMqHstl3h0qZO5codoOix313pggy",
  }, // Example hashed password
];

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public")));

app.post("/login", async (req, res) => {
  const { username, password } = req.body;
  const user = users.find((u) => u.username === username);
  if (user && (await bcrypt.compare(password, user.password))) {
    res.json({ success: true });
  } else {
    res.json({ success: false, message: "Invalid username or password" });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
